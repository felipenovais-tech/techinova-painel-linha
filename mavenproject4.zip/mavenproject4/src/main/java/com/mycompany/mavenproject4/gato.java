/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.mavenproject4;

import javax.swing.JOptionPane;

/**
 *
 * @author 26175344
 */
public class gato extends Animal{
   void miar(){
       System.out.println("Miauu!");
   }
}


