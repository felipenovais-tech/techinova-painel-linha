/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.mavenproject4;


/**
 *
 * @author 26175344
 */
public class cachorro extends Animal{
   void latir(){
       System.out.println("Au Au!!");
   }
    
}


