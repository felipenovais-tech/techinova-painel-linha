/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.mavenproject4;

/**
 *
 * @author 26175344
 */
public class Animal {
     String nome;
    int idade;
    
 void comer(){
        System.out.println("o animal "+this.nome+" esta Comendo");
    }
    
    void dormir(){
        System.out.println("o animal "+this.nome+" esta dormindo");
    }
}



