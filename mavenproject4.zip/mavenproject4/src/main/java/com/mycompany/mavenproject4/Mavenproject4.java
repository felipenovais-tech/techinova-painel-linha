/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.mavenproject4;

import javax.swing.JOptionPane;

/**
 *
 * @author 26175344
 */
public class Mavenproject4 {

    public static void main(String[] args) {
        gato gato1 = new gato();
        cachorro cachorro1 = new cachorro();
        
        gato1.nome = "gato";
        gato1.idade = 5;
        gato1.comer();
        
        cachorro1.nome = "cachorro";
        cachorro1.idade = 10;
        cachorro1.comer();        
        
    }
}
